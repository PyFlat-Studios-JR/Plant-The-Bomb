# Requirements:
- Python 3
- Pip

# Run:
- Move the Folder to your Favourite location
- Double Click Start.bat

# Control
1. Key: W,A,S,D
    - Move Up,Left,Down,Right
2. Key: Space
    - Place a Bomb
3. Key: T
    - Place Time-Bomb(Detonate: <#>)
4. Key: Y
    - Place Dynamite
5. Key: M
    - Place Smoke Bomb


